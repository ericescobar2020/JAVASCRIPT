prompt("Cual es mi edad");
'25'
const edade= prompt("¿Cual es tu edad?")
undefined
edade
'23'
const eda_er = Number(edade); 
undefined
eda_er
23