const num = 10; 
let fact= 1;  
let i=1;

while (i<=num){
    fact = fact*i;
    i++;
}
console.log(fact);