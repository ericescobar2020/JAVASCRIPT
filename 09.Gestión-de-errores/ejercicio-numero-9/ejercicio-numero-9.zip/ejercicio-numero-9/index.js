const logger =require('./logger')








// logger.log("hola estoy resolviendo el ejercicio numero 9 de javascript");
logger.info("esto es un mensaje informativo");
logger.debug("esto es un mensaje de debug"); 
logger.warn("esto es un mensaje de advertencia");
logger.error("esto es un error");
