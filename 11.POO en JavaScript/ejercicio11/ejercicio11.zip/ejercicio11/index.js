class estudiante {
    constructor (nombre, asignaturas){
        this.nombre = nombre
        this.asignaturas= asignaturas

    }
    obtenDatos (){
        console.log(`Hola, mi nombre es ${this.nombre}, estoy aprendiendo ${this.asignaturas}`)
    }
}

const estudianteDeOpen = new estudiante ("Eric Escobar", "JavaScript, Html, Css")
console.log(estudianteDeOpen)
estudianteDeOpen.obtenDatos()