
const perfil= {
    nombre: "Eric",
    edad: 25, 
    Dasarrolador: false, 
    fechaDeNacimiento: "03 de febrero 1997",
    LibroFavorito: {
        titulo: "La magia de pensar en grande",
        autor: "David J. Schwartz",
        fechaDeLanzamiento: 1959, 
        url: "http://oceano.mx/obras/la-magia-de-pensar-en-grande-david-j-schwartz-10836.aspx"
    }

}